
	Etudiants:
	1- TIGA Abdoul-Wakilou (GL)
	2- AYHI Judicael (GL)

NB: Retrouvez le diagramme de classe refais et les captures d'IHM dans le dossier "Captures"
	---------------------------------
Consignes:

	1. Etablissez les relations entre les tables.
	2. Ecrivez les classes « Entity » Java correspondants au diagramme UML
	3. Ecrivez les classes repository associées aux classes
	4. Ajoutez les méthodes JPA Repository permettant :
		• de lister tous les clients d’une agence,
		• de rechercher les clients par nom et prénom
		• De lister tous les clients d’une banque qui sont en découvert
	5. En utilisant les controllers Spring et les JSP, développez les écrans permettant :
		• de lister les clients d’une agence
		• D’enregistrer via un formulaire un nouveau client dans une agence
		• De lister tous les clients qui sont à découvert
	Vous utiliserez un framework comme Bootstrap pour un rendu UX convivial

	---------------------------------
